<?php
$koneksi = mysqli_connect('localhost', 'root', '', 'tugasgaleryfoto');

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
